import serial
import time
i#mport numpy
#import matplotlib.pyplot as plt

# set up the serial line
ser = serial.Serial('/dev/ttyACM3', 9600)
time.sleep(2)
# Read and record the data
data =[]                      # empty list to store the data
for i in range(1000):
    b = ser.readline()         # read a byte string
    string = b.decode()  # decode byte string into Unicode  
    #string = string_n.rstrip() # remove \n and \r
    #flt = float(string)        # convert string to float
    print(string)
    data.append(string)           # add to the end of data list
    time.sleep(0.01)            # wait (sleep) 0.1 seconds

ser.close()

file = open('/home/diya/Desktop/LEAK_DETECTION/new_data2.txt',"wt") #path of file
file.writelines(data)
